import java.util.ArrayList;
/**
 * Write a description of class User here.
 *
 * @author Kate Van Nick
 * @version Spring 2019
 */
public class User
{
    private String name;
    private int age;
    private String gender;
    private double weightLBS;
    private double goalWeightLBS;
    private double weightKILO;
    private double goalWeightKILO;
    private int heightINCH;
    private int heightCM;
    ArrayList<Double> pastWeightLBS;
    ArrayList<Double> pastWeightKILO;

    public User(String inputName, int inputAge, String inputGender)
    {
        name = inputName;
        age = inputAge;
        gender = inputGender;
        pastWeightLBS = new ArrayList<Double>();
        pastWeightKILO = new ArrayList<Double>();
    }

    public double LBStoKILO(double inputWeight)
    {
        return inputWeight * 0.45359237;
    }

    public double KILOtoLBS(double inputWeight)
    {
        return inputWeight / 0.45359237;
    }

    public void INCHtoCM()
    {
        heightCM = (int) (heightINCH / 0.39370);
    }

    public void CMtoINCH()
    {
        heightINCH = (int) (heightCM * 0.39370);
    }

    public void setName(String inputName)
    {
        name = inputName;
    }

    public void setAge(int inputAge)
    {
        age = inputAge;
    }

    public void setWeightLBS(double inputWeight)
    {
        pastWeightLBS.add(weightLBS);
        pastWeightKILO.add(weightKILO);
        weightLBS = inputWeight;
        weightKILO = LBStoKILO(weightLBS);
    }

    public void setWeightKILO(double inputWeight)
    {
        pastWeightKILO.add(weightKILO);
        pastWeightLBS.add(weightLBS);
        weightKILO = inputWeight;
        weightLBS = KILOtoLBS(weightKILO);
    }

    public void setHeightINCH(int inputHeight)
    {
        heightINCH = inputHeight;
        INCHtoCM();
    }

    public void setHeightCM(int inputHeight)
    {
        heightCM = inputHeight;
        CMtoINCH();
    }

    public void setGoalLBS(double inputWeight)
    {
        goalWeightLBS = inputWeight;
        goalWeightKILO = LBStoKILO(goalWeightLBS);
    }

    public void setGoalKILO(double inputWeight)
    {
        goalWeightKILO = inputWeight;
        goalWeightLBS = LBStoKILO(goalWeightKILO);
    }

    public String getName()
    {
        return name;
    }

    public int getAge()
    {
        return age;
    }

    public double getWeightLBS()
    {
        return weightLBS;
    }

    public double getWeightKILO()
    {
        return weightKILO;
    }

    public int getHeightINCH()
    {
        return heightINCH;
    }

    public int getHeightCM()
    {
        return heightCM;
    }

    public double getGoalWeightLBS()
    {
        return goalWeightLBS;
    }

    public double getGoalWeightKILO()
    {
        return goalWeightKILO;
    }

    public String getGender()
    {
        return gender;
    }

    public String toStringHeightINCH()
    {
        return "" + heightINCH / 12 + " ft " + heightINCH % 12 + " in";
    }

} 
