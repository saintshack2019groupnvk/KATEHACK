import java.util.Scanner;

/**
 * Write a description of class Test here.
 *
 * @author Kate, Van, Nick, Natasha
 * @version Spring 2019
 */
public class Test
{
    public static void main(String args[])
    {
        User van = new User("Van", 18);
        van.setWeightLBS(180.0);
        van.setWeightLBS(190.0);
        van.setWeightLBS(200.0);
        System.out.print(van.pastWeightLBS);
        
        van.setHeightINCH(60);
        System.out.println(van.toStringHeightINCH());
        van.setHeightINCH(55);
        System.out.println(van.toStringHeightINCH());
        
        
        
        
        
    }
}
